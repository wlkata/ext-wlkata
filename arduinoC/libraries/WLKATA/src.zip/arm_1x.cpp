#include "ARM_X1.h"

String stateStr[7]={"Offline", "Idle", "Alarm", "Home", "Run", "Hold", "Busy"};

ARM_X1::ARM_X1(){
	
}

/*
  @说明	Gcode初始化
  @参数	num		轴数
  @参数	addr	设备地址，范围：1-247，0为广播地址 -1为无地址
  @返回 无
*/
void ARM_X1::init(uint8_t num, int16_t addr){
	axisNum = num;
	address = addr;
}

/*
  @说明	检查通讯
  @参数	无
  @返回 bool	检查结果（0：无应答 1：应答正常）
*/
/*
bool checkCommunication(){
	bool flag = false;
	sendMsg("$v\r\n", 1);
	while(receive());
	return ;
}
*/
/*
  @说明	发送指令，可选是否等待应答
  @参数	str		要发送的字符串，不需要带地址，自动添加
  @参数	askEn	应答等待使能（0：不等待应答 1：等待应答）
  @返回 无
*/
void ARM_X1::sendMsg(String str, bool askEn){
	if(address != -1) str = "@"+String(address)+str;//添加地址前缀
	while(pSerial->available()) pSerial->read();//清空缓存
	if(serialMonitorMode) monitorSerial->print("	Send: " + str);//串口监视器
	pSerial->print(str);//发送指令
	sendStr = str;
	if(askEn){
		waitAckFlag = 1;//等待应答标志位置1
		sendTime = millis();
		while(waitAckFlag) receive();//接收
	}//需要应答
}

/*
  @说明 接收指令，可选是否等待应答
  @参数	无
  @返回 bool	接收应答标志（0：应答完成 1：等待应答）
*/
bool ARM_X1::receive(){
	String str = "\0";
	if(address == 0){
		waitAckFlag = 0;//等待应答标志位置0
		return waitAckFlag;
	}
	
	while(pSerial->available()){
		while(pSerial->available()){
			char c = pSerial->read();//读取
			str += c;
			if(c == '\n'){//数据有效性
				if(str.endsWith("ok\r\n"));
				else if(str.startsWith("State")!=-1 ) findState(&str, ',', ',');
				else if(str.startsWith("<")!=-1 ) dealstatus(&str);
				else if(str.startsWith("Mirobot") || str.startsWith("Dark3") || str.startsWith("E4")){
					uint8_t size=str.length();
					armVer = str.substring(0,size-2);
				}
				else if(str.startsWith("EXbox")){
					uint8_t size=str.length();
					exboxVer = str.substring(0,size-2);
				}
				else receiveStr = str;
				if(serialMonitorMode)	monitorSerial->print("	Rece: " + str);//串口监视器
				str = "\0";
				waitAckFlag = 0;
			}
		}
		delay(10);//保证接收完整
	}
	if(receiveStr != "\0"){//有应答 但 应答内容无法识别
		if(serialMonitorMode)	monitorSerial->print("	Reply error, Rece: " + receiveStr);//串口监视器
		receiveStr == "\0";
	}
	if(waitAckFlag && millis()-sendTime>ackMaxTime){//无应答 或 应答超时
		status.state = -1;
		if(serialMonitorMode)	monitorSerial->print("	Reply timeout, Rece: " + receiveStr);//串口监视器
		while(1);
		(*func)(sendStr, address);
		waitAckFlag = 0;
	}
	return waitAckFlag;
}

/*
  @说明 获取基本信息，版本号
  @参数	无
  @返回 String
*/
String ARM_X1::getVersions(){
	sendMsg("$v\r\n", 1);
	while(receive());
	return armVer + "\r\n" + exboxVer + "\r\n";
}

/*
  @说明 读取运动状态
  @参数	无
  @返回 int
*/
int ARM_X1::getState(){
	while(millis()-sendTime<STATEDELAY);//给发送预留时间
	sendMsg("O103\r\n", 1);
	while(receive());
	return status.state;
}

/*
  @说明 读取运动状态 字符串类型
  @参数	无
  @返回 String
*/
String ARM_X1::getStateToStr(){
	while(millis()-sendTime<STATEDELAY);//给发送预留时间
	int num = getState();
	if(num==-1) return "Error";
	return stateStr[num];
}

/*
  @说明 读取所有状态
  @参数	无
  @返回 Gcode
*/
String ARM_X1::getStatus(){
	return "?\r\n";
}

/******************** 机械臂运动 ********************/

/*
  @说明 归零
  @参数	mode	0/$H：设备和扩展轴一起归零；
							1/$H1：1轴归零；
							2/$H2：2轴归零；
							3/$H3：3轴归零；
							4/$H4：4轴归零；
							5/$H5：5轴归零；
							6/$H6：6轴归零（仅特定版本设备支持）；
							7/$H7：扩展轴归零（需要接传感器）；
							8/$H：设备轴一起归零；
							9/$HH：设备轴分别归零；
							10/$HE：设备轴最小姿态归零；
  @返回 Gcode
*/
String ARM_X1::homing_Gcode(int mode){
	String str = "\0";
  switch(mode){
		case 0: str += "O105=0\r\n"; break;//$H0
    case 1: str += "O105=1\r\n"; break;//$H1
    case 2: str += "O105=2\r\n"; break;//$H2
    case 3: str += "O105=3\r\n"; break;//$H3
    case 4: str += "O105=4\r\n"; break;//$H4
    case 5: str += "O105=5\r\n"; break;//$H5
    case 6: str += "O105=6\r\n"; break;//$H6
    case 7: str += "O105=7\r\n"; break;//$H7
		case 8: str += "O105\r\n"; break;//$H
		case 9: str += "O105=9\r\n"; break;//$HH
		case 10: str += "O105=10\r\n"; break;//$HE
    default: str += "O105\r\n"; break;//$H
  }
	return str;
}

/*
  @说明 移动到零点位置
  @参数	无
  @返回 Gcode
*/
String ARM_X1::zero_Gcode(){    //设备初始位置
	return "M21 G90 G00 X0 Y0 Z0 A0 B0 C0\r\n";//关节模式运动到零点
}

/*
  @说明 机械臂运动
  @参数	pathMode		路径模式
						MOVEP 点到点运动
						MOVEL 直线运动
						MOVEJ 关节运动
						JUMP  门型运动
	@参数	motionMode	运动模式
						ABS   绝对位置
						INC   相对位置
	@参数	x		x坐标值
	@参数	y		y坐标值
	@参数	z		z坐标值
	@参数	a		a坐标值
	@参数	b		b坐标值
	@参数	c		c坐标值
	@参数	d		d坐标值
	@参数	enExj		d扩展轴联动使能
  @返回 Gcode
*/
String ARM_X1::move_Gcode(uint8_t pathMode, bool motionMode, float x, float y, float z, float a, float b, float c, float d, bool enExj){
	String str = "\0";
	switch(pathMode){
		case MOVEP: str += "M20 G00"; break;
		case MOVEL: str += "M20 G01"; break;
		case MOVEJ: str += "M21 G01"; break;
		case JUMP : str += "M20 G05"; break;
	}
	switch(motionMode){
		case ABS: str += "G90"; break;
		case INC: str += "G91"; break;
	}

	str += "X"; str += x;
	str += "Y"; str += y;
	str += "Z"; str += z;
	str += "A"; str += a;
	str += "B"; str += b;
	str += "C"; str += c;
	if(enExj == true)
		str += "D"; str += d;
	str += "\r\n";
	return str;
}

/*
  @说明 机械臂运动
  @参数	pathMode		路径模式
						MOVEP 点到点运动
						MOVEL 直线运动
						JUMP  门型运动
	@参数	motionMode	运动模式
						ABS   绝对位置
						INC   相对位置
	@参数	x		x坐标值
	@参数	y		y坐标值
	@参数	z		z坐标值
	@参数	a		a坐标值
	@参数	b		b坐标值
	@参数	c		c坐标值
  @返回 Gcode
*/
String ARM_X1::movePose_Gcode(uint8_t pathMode, bool motionMode, float x, float y, float z, float a, float b, float c){
	return move_Gcode(pathMode, motionMode, x, y, z, a, b, c);
}

/*
  @说明 机械臂运动，含扩展轴
  @参数	pathMode		路径模式
						MOVEP 点到点运动
						MOVEL 直线运动
						JUMP  门型运动
	@参数	motionMode	运动模式
						ABS   绝对位置
						INC   相对位置
	@参数	x		x坐标值
	@参数	y		y坐标值
	@参数	z		z坐标值
	@参数	a		a坐标值
	@参数	b		b坐标值
	@参数	c		c坐标值
	@参数	d		d坐标值
  @返回 Gcode
*/
String ARM_X1::movePoseWithExj_Gcode(uint8_t pathMode, bool motionMode, float x, float y, float z, float a, float b, float c, float d){
	return move_Gcode(pathMode, motionMode, x, y, z, a, b, c, d, true);
}

/*
  @说明 机械臂圆弧插补运动
  @参数	pathMode		路径模式	
						CW 	顺时针画弧
						CCW 逆时针画弧
	@参数	motionMode	运动模式
						ABS	绝对位置
						INC	相对位置
	@参数	x		x坐标值
	@参数	y		y坐标值
	@参数	z		z坐标值
	@参数	r		圆弧半径
  @返回 Gcode
*/
String ARM_X1::moveArc_Gcode(bool pathMode, bool motionMode, float x, float y, float z, float r){
	String str = "\0";
	str += "M20";
	switch(motionMode){
		case ABS: str += "G90"; break;
		case INC: str += "G91"; break;
	}
	switch(pathMode){
		case CW : str += "G02"; break;
		case CCW: str += "G03"; break;
	}
	str += "X"; str += x;
	str += "Y"; str += y;
	str += "Z"; str += z;
	str += "R"; str += r;
	str += "\r\n";
	return str;
}

/*
  @说明 机械臂关节运动
  @参数	motionMode	运动模式
						ABS	绝对位置
						INC	相对位置
	@参数	j1		1轴角度值
	@参数	j2		2轴角度值
	@参数	j3		3轴角度值
	@参数	j4		4轴角度值
	@参数	j5		5轴角度值
	@参数	j6		6轴角度值
  @返回 Gcode
*/
String ARM_X1::moveJoints_Gcode(bool motionMode, float j1, float j2, float j3, float j4, float j5, float j6){
	return move_Gcode(MOVEJ, motionMode, j1, j2, j3, j4, j5, j6);
}

//点到点运动
String ARM_X1::moveP_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEP, ABS, x, y, z, a, b, c, d, enExj);
}
//直线运动
String ARM_X1::moveL_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEL, ABS, x, y, z, a, b, c, d, enExj);
}
//关节运动
String ARM_X1::moveJ_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEJ, ABS, x, y, z, a, b, c, d, enExj);
}
//直线门型运动
String ARM_X1::jump_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(JUMP, ABS, x, y, z, a, b, c, d, enExj);
}
//点到点相对运动
String ARM_X1::moveIncP_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEP, INC, x, y, z, a, b, c, d, enExj);
}
//直线相对运动
String ARM_X1::moveIncL_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEL, INC, x, y, z, a, b, c, d, enExj);
}
//关节相对运动
String ARM_X1::moveIncJ_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEJ, INC, x, y, z, a, b, c, d, enExj);
}
//直线门型相对运动
String ARM_X1::jumpInc_Gcode(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(JUMP, INC, x, y, z, a, b, c, d, enExj);
}
/*
//圆弧运动
String ARM_X1::moveC(float x, float y, float z, float r, float b, float c, float d, bool enExj){
	return "";
}
//圆弧相对运动
String ARM_X1::moveIncC(float x, float y, float z, float a, float b, float c, float d, bool enExj){
	return move(MOVEP, ABS, x, y, z, a, b, c);
}
*/

/*
  @说明 设置运动速度
	@参数	speed		速度值?
  @返回 Gcode
*/
String ARM_X1::setMotionSpeed_Gcode(float speed){
	String str = "\0";
	str += "F";
	str += speed;
	str += "\r\n";
  return str;
}

/*
  @说明 设置运动速度百分比
	@参数	ratio		运动速度百分比 范围：1-100
  @返回 Gcode
*/
String ARM_X1::motionSpeedRatio_Gcode(uint8_t ratio){
	String str = "\0";
	str += "H";
	str += ratio;
	str += "\r\n";
  return str;
}

/*
  @说明 暂停运动
	@参数	无
  @返回 Gcode
*/
String ARM_X1::movePause_Gcode(){
	return "!\r\n";
}

/*
  @说明 继续运动
	@参数	无
  @返回 Gcode
*/
String ARM_X1::moveContinue_Gcode(){
	return "~\r\n";
}

/*
  @说明 停止运动
	@参数	无
  @返回 Gcode
*/
String ARM_X1::moveStop_Gcode(){
	return "%\r\n";
}

/******************** 扩展轴 ********************/

/*
  @说明 设置扩展轴减速比
	@参数	ratio		1个单位对应的脉冲数量
  @返回 Gcode
*/
String ARM_X1::setExjRatio_Gcode(float ratio){
	exj_ratio = ratio;
}

/*
  @说明 扩展轴运动-单位脉冲
  @参数	motionMode	运动模式
						ABS	绝对位置
						INC	相对位置
	@参数	d		扩展轴值
  @返回 Gcode
*/
String ARM_X1::moveExjPulse_Gcode(bool motionMode, int32_t d){
	String str = "\0";
	str += "M21";
	switch(motionMode){
		case ABS: str += "G90"; break;
		case INC: str += "G91"; break;
	}
	str += "G00 D";
	str += d;
	str += "\r\n";
	return str;
}

/*
  @说明 扩展轴运动-单位距离
  @参数	motionMode	运动模式
						ABS	绝对位置
						INC	相对位置
	@参数	d		扩展轴值
  @返回 Gcode
*/
String ARM_X1::moveExjDist_Gcode(bool motionMode, float d){
	String str = "\0";
	str += "M21";
	switch(motionMode){
		case ABS: str += "G90"; break;
		case INC: str += "G91"; break;
	}
	str += "G00 D";
	str += d*exj_ratio;
	str += "\r\n";
	return str;
}

/******************** 末端工具 ********************/

/*
  @说明 控制电动夹爪状态
  @参数	num		电动夹爪状态 （0/OFF:关闭 1/OPEN:打开 2/CLOSE:关闭）
  @返回 Gcode
*/	
String ARM_X1::setEndtGripper_Gcode(uint8_t num){
	String str = "\0";
	if(num == OFF) str = "M3 S0\r\n";
	else if(num == OPEN) str = "M3 S40\r\n";
	else if(num == CLOSE) str = "M3 S60\r\n";
	return str;
}

/*
  @说明 控制气泵状态
  @参数	num		pwm占空比 （0/OFF:关闭 1/IN:正压 2/OUT:负压）
  @返回 Gcode
*/	
String ARM_X1::setEndtPump_Gcode(uint8_t num){
	String str = "\0";
	if(num == OFF) str = "M3 S0\r\n";
	else if(num == OUT) str = "M3 S500\r\n";
	else if(num == IN) str = "M3 S1000\r\n";
	return str;
}

/*
  @说明 pwm输出，控制器黄色接口
  @参数	num		pwm占空比 范围：0~1000
  @返回 Gcode
*/	
String ARM_X1::setEndtPwm_Gcode(uint16_t num){
	return "M3 S"+String(num)+"\r\n";
}

/*
  @说明 保存参数
  @参数	无
  @返回 Gcode
*/
String saveParams_Gcode(){
	return "$S\r\n";
}

/******************** SD ********************/

/*
  @说明 运行文件名
  @参数	fileName	文件名
	@参数	loop			循环标志 （false:不循环 true:循环）
  @返回 Gcode
*/	
String ARM_X1::runFile_Gcode(String fileName, bool loop){
	String str = "\0";
	if(loop) str += "O112=";
	else str += "O111=";
	str += fileName;
	str += "\r\n";
	return str;
}

/*
  @说明 运行文件号
  @参数	fileNum		文件号，取文件名称前两位数字
	@参数	loop			循环标志 （false:不循环 true:循环）
  @返回 Gcode
*/
String ARM_X1::runFileNum_Gcode(uint8_t fileNum, bool loop){
	String str = "\0";
	if(loop) str += "O116=";
	else str += "O116=";
	str += fileNum;
	str += "\r\n";
	return str;
}

/*
  @说明 设备重启
  @参数	无
  @返回 Gcode
*/
String ARM_X1::Gcodereset_Gcode(){
	return "O100\r\n";
}












/*
  @说明 超时提醒函数
  @参数	str		未应答的指令
  @参数	addr	未应答的设备地址
  @返回 无
*/
void ARM_X1::infoTimeout(String str, int addr){
	
}

/*
  @说明 查找字符串中的数据
  @参数	str			状态所在的字符串
	@参数	fStr		要查找的字符串
	@参数	num			寻找字符串后的第几个数据
	@参数	retStr	读取到的数据
  @返回 bool 		读取成功标志（0：失败 1：成功）
*/
bool ARM_X1::findNum(String* str, String fStr, uint8_t num, String* retStr){
	uint8_t startAddr, endAddr;
	startAddr = (*str).indexOf(fStr);
	if(startAddr == -1) return 0;
	endAddr = (*str).indexOf(':', startAddr);
	if(endAddr == -1) return 0;
	for(uint8_t i=0; i<num; i++){
		startAddr = endAddr+1;
		endAddr = (*str).indexOf(', ', startAddr);
		if(endAddr == -1) return 0;
	}
	*retStr = (*str).substring(startAddr, endAddr);
	return 1;
}

/*
  @说明 查找字符串中的运动状态
  @参数	str		状态所在的字符串
	@参数	c1		开始字符
	@参数	c2		结束字符
  @返回 bool 	读取成功标志（0：失败 1：成功）
*/
bool ARM_X1::findState(String* str, char c1, char c2){
	uint8_t startAddr, endAddr;
	status.state = -1;
	startAddr = (*str).indexOf(c1);
	if(startAddr == -1) return 0;
	startAddr++;
	endAddr = (*str).indexOf(c2, startAddr);
	if(endAddr == -1) return 0;
	String s = (*str).substring(startAddr, endAddr);
	for(uint8_t i=0; i<7; i++){
		if(s == stateStr[i]){
			status.state = i;
			return 1;
		}
	}
	return 0;
}

/*
  @说明 解析返回状态
  @参数	str		状态字符串
  @返回 bool 	读取成功标志（0：失败 1：成功）
*/
bool ARM_X1::dealstatus(String* str){
	String s;
	//获取状态
	if(findState(str, '<', ', ')==0) return 0;
	//获取角度
	for(uint8_t i=0; i<7; i++){
		if(findNum(str, "Angle", i+1, &s)==0) return 0;
		status.angle[(i+3)%7] = s.toFloat();
	}
	//获取位置
	for(uint8_t i=0; i<6; i++){
		if(findNum(str, "Cartesian", i+1, &s)==0) return 0;
		status.cartesian[i] = s.toFloat();
	}
	//获取pwm
	if(findNum(str, "Pump", 1, &s)==0) return 0;
	status.pumpPwm = s.toInt();
	return 1;	
}
