#ifndef ARM_X1_H
#define ARM_X1_H

#include "Arduino.h"

class ARM_X1{
  public:
    ARM_X1();
    void init(uint8_t num, int16_t addr=-1);//Gcode初始化 参数：轴数 设备地址 

		int getState();//读取运动状态
		String getStateToStr();//读取运动状态 字符串类型
		String getStatus();//读取所有状态
		
		//机械臂运动
		String homing_Gcode(int mode = -1);//归航
		String zero_Gcode();//回零点
		
		String move_Gcode(uint8_t pathMode, bool motionMode, float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//移动
		
		String movePose_Gcode(uint8_t pathMode, bool motionMode, float x, float y, float z, float a, float b, float c);//机械臂位置运动
		String movePoseWithExj_Gcode(uint8_t pathMode, bool motionMode, float x, float y, float z, float a, float b, float c, float d);//机械臂位置运动，含扩展轴
		String moveArc_Gcode(bool pathMode, bool motionMode, float x, float y, float z, float r);//机械臂圆弧插补运动
		String moveJoints_Gcode(bool motionMode, float j1, float j2, float j3, float j4, float j5, float j6);//机械臂关节运动

		String moveP_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//点到点运动
		String moveL_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//直线运动
		String moveJ_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//关节运动
		String jump_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj);//门型轨迹运动
		String moveIncP_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//点到点相对运动
		String moveIncL_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//直线相对运动
		String moveIncJ_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//关节相对运动
		String jumpInc_Gcode(float x, float y, float z, float a, float b, float c, float d=0, bool enExj=flase);//门型轨迹相对运动

		String setMotionSpeed_Gcode(float speed);//设置运动速度
		String motionSpeedRatio_Gcode(uint8_t ratio);//设置运动速度百分比
		//void motionParams();//设置运动参数
		
		String movePause_Gcode();//暂停运动
		String moveContinue()Gcode;//继续运动
		String moveStop_Gcode();//停止运动
		String reset_Gcode(); //设备重启
		
		//扩展轴
		String setExjRatio_Gcode(float ratio);//设置扩展轴减速比
		String moveExjPulse_Gcode(bool motionMode, int32_t d);//扩展轴运动-单位脉冲
		String moveExjDist_Gcode(bool motionMode, float d);//扩展轴运动-单位距离
		
		//末端工具
    String setEndtGripper_Gcode(uint8_t num);//控制电动夹爪状态
    String setEndtPump_Gcode(uint8_t num);//控制气泵状态
    String setEndtPwm_Gcode(uint16_t num);//控制pwm输出脉宽
		
		//SD
		String runFile_Gcode(String fileName, bool loop = false);	//运行文件名
		String runFileNum_Gcode(uint8_t fileNum, bool loop = false);	//运行文件号
		
		String saveParams_Gcode();//保存参数
		
  protected:
		uint8_t axisNum; //轴数
		int address;//设备地址
	
		STATUS_MIROBOT status;//所有状态信息
		HardwareSerial *pSerial;//串口指针
		HardwareSerial *monitorSerial;//监视器串口指针
		bool serialMonitorMode = 0;//监视器模式 （0/OFF:关闭 1/ON:开启）
		
		uint32_t ackMaxTime=OUTTIME;//最大应答时间 ms
		void (*func)(String, int);//应答超时的回调函数
		bool waitAckFlag = 0;//等待应答标志位
		uint32_t sendTime;//数据发送时间
		String sendStr;//发送字符串
		String receiveStr;//接收字符串
		float exj_ratio=1;//扩展轴减速比脉冲
		String armVer="\0";//机械臂版本
		String exboxVer="\0";//扩展盒版本
		String versions="\0";//版本
		
		void infoTimeout(String str, int addr);//超时提醒函数
		bool findNum(String* str, String fStr, uint8_t num, String* retStr);//查找特定字符串
		bool findState(String* str, char c1, char c2);//查找状态字符串
		bool dealstatus(String* str);//解析返回状态
		
};

#endif
